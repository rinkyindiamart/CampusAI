# CampusAI — Live Deployment Guide

This package is prepared for online deployment.

## Files added for hosting
- Procfile — starts the Flask app with Gunicorn
- runtime.txt — Python runtime hint
- .gitignore — ignores local environment/database files

## Important
This is a BCA prototype. SQLite is suitable for demo/testing; production deployment should use a managed database and stronger security.

## Demo logins
Student: student@campusai.demo / 123456
Faculty: faculty@campusai.demo / faculty123
College: admin@campusai.demo / admin123
Admin: superadmin@campusai.demo / super123
