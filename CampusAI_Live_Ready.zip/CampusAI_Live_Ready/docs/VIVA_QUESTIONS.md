# Viva Questions & Short Answers

1. Why Flask? — Lightweight Python web framework suitable for rapid development.
2. Why SQLite? — Simple relational database suitable for a college prototype and easy to deploy.
3. What is the role of the database? — It stores users, exams, questions, attempts, attendance and other records.
4. How is exam evaluation done? — Submitted objective options are compared with stored answer keys.
5. How is the timer implemented? — JavaScript counts down seconds and submits the form when time reaches zero.
6. Why separate roles? — Students, faculty/college staff and admins require different permissions.
7. What is responsive design? — UI adapts to mobile, tablet and desktop screen sizes.
8. How can real AI be added? — Connect a trusted LLM API through a secured backend service.
9. How would descriptive answers be checked? — Store them and send them to a faculty/review workflow or controlled AI-assisted evaluation, followed by validation.
10. What security improvements are needed? — Password hashing, CSRF protection, session hardening, access controls, secure uploads, audit logs and backups.
11. What is CRUD? — Create, Read, Update and Delete operations.
12. What is normalization? — Organizing relational data to reduce redundancy and improve integrity.
