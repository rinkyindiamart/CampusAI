# CampusAI — Full BCA Project Prototype

## Modules
1. Student portal
2. College/faculty portal
3. System admin dashboard
4. Student registration by college
5. Timed examination engine
6. Automatic objective-answer evaluation
7. Exam result history
8. Attendance management/view
9. Notes and question-bank area
10. Career roadmap
11. Resume builder
12. Jobs/internship directory
13. Skill institute directory
14. AI assistant interface
15. CSV exam report
16. Responsive mobile/laptop UI

## Demo accounts
Student: student@campusai.demo / 123456
Faculty: faculty@campusai.demo / faculty123
College: admin@campusai.demo / admin123
Admin: superadmin@campusai.demo / super123

## Run on Windows
1. Install Python 3.10+
2. Open Command Prompt in this folder
3. `py -m venv venv`
4. `venv\Scripts\activate`
5. `pip install -r requirements.txt`
6. `python app.py`
7. Open http://127.0.0.1:5000

## Run on Linux/macOS
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
Open http://127.0.0.1:5000

The database is automatically created at instance/campusai.db on first run.

## Important
This is a college-project prototype, not a production ERP. For real deployment add secure password hashing, CSRF protection, role/permission enforcement, file upload security, backups, audit logs, privacy/consent, verified employer/institute onboarding, secure exam controls and a real LLM API.
