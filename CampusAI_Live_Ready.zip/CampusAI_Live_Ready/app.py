
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
import sqlite3, os, datetime, io, csv

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,"instance","campusai.db")
app=Flask(__name__)
app.secret_key="campusai-bca-project-secret"

def con():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=con(); q=c.cursor()
    q.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,role TEXT NOT NULL,course TEXT,semester TEXT,phone TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS subjects(
      id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,course TEXT,semester TEXT);
    CREATE TABLE IF NOT EXISTS notes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,subject TEXT,course TEXT,unit TEXT,content TEXT,created_at TEXT);
    CREATE TABLE IF NOT EXISTS exams(
      id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,subject TEXT,course TEXT,semester TEXT,
      duration INTEGER DEFAULT 60,instructions TEXT,active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS questions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,exam_id INTEGER,question TEXT,a TEXT,b TEXT,c TEXT,d TEXT,
      answer TEXT,marks INTEGER DEFAULT 1,FOREIGN KEY(exam_id) REFERENCES exams(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS attempts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,exam_id INTEGER,score REAL,total REAL,
      started_at TEXT,submitted_at TEXT,status TEXT,FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS attendance(
      id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,subject TEXT,classes INTEGER,attended INTEGER,
      FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS jobs(
      id INTEGER PRIMARY KEY AUTOINCREMENT,company TEXT,title TEXT,location TEXT,skills TEXT,
      apply_url TEXT,verified INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS institutes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,course TEXT,mode TEXT,duration TEXT,
      website TEXT,verified INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS resumes(
      id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,summary TEXT,skills TEXT,projects TEXT,
      education TEXT,experience TEXT,updated_at TEXT);
    CREATE TABLE IF NOT EXISTS announcements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,created_at TEXT);
    """)
    demo=[
      ("Demo Student","student@campusai.demo","123456","student","BCA","6"),
      ("Demo Faculty","faculty@campusai.demo","faculty123","faculty","BCA","6"),
      ("College Administrator","admin@campusai.demo","admin123","college","BCA",""),
      ("System Administrator","superadmin@campusai.demo","super123","admin","","")
    ]
    for x in demo:
        try:q.execute("INSERT INTO users(name,email,password,role,course,semester,created_at) VALUES(?,?,?,?,?,?,?)",(*x,datetime.datetime.now().isoformat()))
        except sqlite3.IntegrityError:pass
    if q.execute("SELECT COUNT(*) n FROM subjects").fetchone()["n"]==0:
        q.executemany("INSERT INTO subjects(name,code,course,semester) VALUES(?,?,?,?)",[
          ("Programming in Python","BCA-301","BCA","6"),("Database Management Systems","BCA-302","BCA","6"),
          ("Web Technology","BCA-303","BCA","6"),("Computer Networks","BCA-304","BCA","6")])
    if q.execute("SELECT COUNT(*) n FROM exams").fetchone()["n"]==0:
        q.execute("INSERT INTO exams(title,subject,course,semester,duration,instructions) VALUES(?,?,?,?,?,?)",
                  ("BCA Programming Unit Test","Programming in Python","BCA","6",60,"Attempt all questions. Objective answers are evaluated automatically."))
        eid=q.lastrowid
        qs=[
          ("Which structure follows LIFO?","Queue","Stack","Tree","Graph","B",1),
          ("Python files normally use which extension?","py","java","html","sql","A",1),
          ("Which keyword defines a function in Python?","func","define","def","function","C",1),
          ("Which is immutable in Python?","List","Dictionary","Set","Tuple","D",1),
          ("Which language structures a web page?","HTML","Python","SQL","C","A",1)
        ]
        q.executemany("INSERT INTO questions(exam_id,question,a,b,c,d,answer,marks) VALUES(?,?,?,?,?,?,?,?)",
                      [(eid,*x) for x in qs])
    if q.execute("SELECT COUNT(*) n FROM notes").fetchone()["n"]==0:
        q.executemany("INSERT INTO notes(title,subject,course,unit,content,created_at) VALUES(?,?,?,?,?,?)",[
          ("Python Unit 1","Programming in Python","BCA","Unit 1","Variables, data types, operators, input/output and control flow.","2026"),
          ("DBMS Quick Notes","Database Management Systems","BCA","Unit 1","Keys, normalization, ER model, SQL commands and transactions.","2026"),
          ("Web Technology Basics","Web Technology","BCA","Unit 1","HTML structure, CSS selectors, JavaScript basics and client-server concepts.","2026")])
    if q.execute("SELECT COUNT(*) n FROM jobs").fetchone()["n"]==0:
        q.executemany("INSERT INTO jobs(company,title,location,skills,apply_url,verified) VALUES(?,?,?,?,?,?)",[
          ("TechNova Solutions","Web Developer Intern","Gurugram","HTML, CSS, JavaScript","https://example.com",1),
          ("DataBridge","Python Intern","Remote","Python, SQL","https://example.com",1),
          ("CloudWorks","IT Support Trainee","Noida","Networking, Linux","https://example.com",0)])
    if q.execute("SELECT COUNT(*) n FROM institutes").fetchone()["n"]==0:
        q.executemany("INSERT INTO institutes(name,course,mode,duration,website,verified) VALUES(?,?,?,?,?,?)",[
          ("SkillHub Academy","Full Stack Development","Online","12 Weeks","https://example.com",1),
          ("CodeCampus","Python & Data Analytics","Hybrid","10 Weeks","https://example.com",1)])
    if q.execute("SELECT COUNT(*) n FROM announcements").fetchone()["n"]==0:
        q.execute("INSERT INTO announcements(title,body,created_at) VALUES(?,?,?)",
                  ("Welcome to CampusAI","Use your dashboard for exams, notes, attendance and career resources.","2026-09-28"))
    # attendance for demo student
    sid=q.execute("SELECT id FROM users WHERE email='student@campusai.demo'").fetchone()["id"]
    if q.execute("SELECT COUNT(*) n FROM attendance WHERE user_id=?",(sid,)).fetchone()["n"]==0:
        q.executemany("INSERT INTO attendance(user_id,subject,classes,attended) VALUES(?,?,?,?)",[
          (sid,"Programming in Python",40,34),(sid,"DBMS",42,32),(sid,"Web Technology",38,34),(sid,"Computer Networks",40,30)])
    c.commit(); c.close()

def auth(role=None):
    if not session.get("uid"): return False
    return role is None or session.get("role") in role

@app.context_processor
def common():
    return {"logged":bool(session.get("uid")),"user_name":session.get("name"),"user_role":session.get("role")}

@app.route("/")
def home(): return render_template("home.html")

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        c=con(); u=c.execute("SELECT * FROM users WHERE email=? AND password=?",(request.form["email"],request.form["password"])).fetchone(); c.close()
        if u:
            session.update(uid=u["id"],name=u["name"],role=u["role"],course=u["course"],semester=u["semester"])
            return redirect(url_for("dashboard"))
        flash("Invalid login details.")
    return render_template("login.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.route("/dashboard")
def dashboard():
    if not auth(): return redirect("/login")
    c=con()
    u=c.execute("SELECT * FROM users WHERE id=?",(session["uid"],)).fetchone()
    stats={
      "exams":c.execute("SELECT COUNT(*) n FROM exams WHERE active=1").fetchone()["n"],
      "notes":c.execute("SELECT COUNT(*) n FROM notes").fetchone()["n"],
      "jobs":c.execute("SELECT COUNT(*) n FROM jobs").fetchone()["n"],
      "students":c.execute("SELECT COUNT(*) n FROM users WHERE role='student'").fetchone()["n"]
    }
    att=c.execute("SELECT COALESCE(SUM(attended)*100.0/NULLIF(SUM(classes),0),0) p FROM attendance WHERE user_id=?",(u["id"],)).fetchone()["p"]
    anns=c.execute("SELECT * FROM announcements ORDER BY id DESC LIMIT 5").fetchall()
    c.close(); return render_template("dashboard.html",u=u,stats=stats,attendance=round(att,1),anns=anns)

@app.route("/exams")
def exams():
    if not auth(): return redirect("/login")
    c=con(); rows=c.execute("SELECT * FROM exams WHERE active=1 ORDER BY id DESC").fetchall(); c.close()
    return render_template("exams.html",rows=rows)

@app.route("/exam/<int:eid>",methods=["GET","POST"])
def take_exam(eid):
    if not auth(["student"]): return redirect("/login")
    c=con(); ex=c.execute("SELECT * FROM exams WHERE id=?",(eid,)).fetchone()
    qs=c.execute("SELECT * FROM questions WHERE exam_id=?",(eid,)).fetchall()
    if not ex: c.close(); return "Exam not found",404
    if request.method=="POST":
        score=0; total=sum(q["marks"] for q in qs)
        for q in qs:
            if request.form.get(str(q["id"]))==q["answer"]: score+=q["marks"]
        now=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("INSERT INTO attempts(user_id,exam_id,score,total,started_at,submitted_at,status) VALUES(?,?,?,?,?,?,?)",
                  (session["uid"],eid,score,total,now,now,"Evaluated"))
        c.commit(); c.close()
        return render_template("result.html",ex=ex,score=score,total=total,when=now)
    c.close(); return render_template("exam.html",ex=ex,qs=qs)

@app.route("/results")
def results():
    if not auth(): return redirect("/login")
    c=con()
    if session["role"]=="student":
        rows=c.execute("""SELECT attempts.*,exams.title FROM attempts JOIN exams ON exams.id=attempts.exam_id
                          WHERE user_id=? ORDER BY attempts.id DESC""",(session["uid"],)).fetchall()
    else:
        rows=c.execute("""SELECT attempts.*,users.name,exams.title FROM attempts
                          JOIN users ON users.id=attempts.user_id JOIN exams ON exams.id=attempts.exam_id
                          ORDER BY attempts.id DESC""").fetchall()
    c.close(); return render_template("results.html",rows=rows,staff=session["role"]!="student")

@app.route("/notes")
def notes():
    if not auth(): return redirect("/login")
    c=con(); rows=c.execute("SELECT * FROM notes ORDER BY id DESC").fetchall(); c.close()
    return render_template("notes.html",rows=rows)

@app.route("/attendance")
def attendance():
    if not auth(): return redirect("/login")
    c=con()
    if session["role"]=="student":
        rows=c.execute("SELECT *,ROUND(attended*100.0/NULLIF(classes,0),1) pct FROM attendance WHERE user_id=?",(session["uid"],)).fetchall()
    else:
        rows=c.execute("""SELECT attendance.*,users.name,ROUND(attended*100.0/NULLIF(classes,0),1) pct
                          FROM attendance JOIN users ON users.id=attendance.user_id ORDER BY users.name""").fetchall()
    c.close(); return render_template("attendance.html",rows=rows,staff=session["role"]!="student")

@app.route("/career")
def career(): return render_template("career.html") if auth() else redirect("/login")

@app.route("/jobs")
def jobs():
    if not auth(): return redirect("/login")
    c=con(); rows=c.execute("SELECT * FROM jobs ORDER BY verified DESC,id DESC").fetchall(); c.close()
    return render_template("jobs.html",rows=rows)

@app.route("/institutes")
def institutes():
    if not auth(): return redirect("/login")
    c=con(); rows=c.execute("SELECT * FROM institutes ORDER BY verified DESC,id DESC").fetchall(); c.close()
    return render_template("institutes.html",rows=rows)

@app.route("/resume",methods=["GET","POST"])
def resume():
    if not auth(["student"]): return redirect("/login")
    c=con()
    if request.method=="POST":
        c.execute("""INSERT INTO resumes(user_id,summary,skills,projects,education,experience,updated_at)
                    VALUES(?,?,?,?,?,?,?)""",(session["uid"],request.form["summary"],request.form["skills"],
                    request.form["projects"],request.form["education"],request.form["experience"],
                    datetime.datetime.now().isoformat()))
        c.commit(); flash("Resume profile saved.")
    r=c.execute("SELECT * FROM resumes WHERE user_id=? ORDER BY id DESC LIMIT 1",(session["uid"],)).fetchone()
    c.close(); return render_template("resume.html",r=r)

@app.route("/ai",methods=["POST"])
def ai():
    if not auth(): return jsonify(reply="Please login first.")
    msg=request.json.get("message","").lower()
    responses=[
      (["exam","test","paper"],"Open Examination Center. First revise Notes, then start the timed test. Objective questions are checked automatically in this prototype."),
      (["bca","career","job","future"],"For BCA, explore software development, web development, testing, data/analytics, cloud/IT, cybersecurity and higher studies. Use Career Roadmap to build a skill sequence."),
      (["resume","cv"],"Open Resume Builder and add your summary, education, skills, projects and experience. Keep project descriptions specific and measurable."),
      (["attendance","present"],"Open Attendance to see subject-wise percentage. Colleges can use the staff portal to review student attendance."),
      (["note","study","prepare"],"Open Notes & Study Material. In a production version, faculty can upload PDFs, videos and unit-wise question banks."),
      (["course","institute","skill"],"Open Skill Institutes. Only verified/authorized providers should be listed in a real deployment."),
      (["company","internship","apply"],"Open Jobs & Internships. A real deployment should verify employer identity and link applications to official career pages."),
    ]
    reply="I can guide you to Exams, Notes, Attendance, Career, Resume, Jobs and Skill Institutes. Try asking: 'How should I prepare for my exam?'"
    for keys,r in responses:
        if any(k in msg for k in keys): reply=r; break
    return jsonify(reply=reply)

# College/faculty/admin management
@app.route("/staff")
def staff():
    if not auth(["college","faculty","admin"]): return redirect("/login")
    c=con()
    students=c.execute("SELECT * FROM users WHERE role='student' ORDER BY name").fetchall()
    exams=c.execute("SELECT * FROM exams ORDER BY id DESC").fetchall()
    attempts=c.execute("""SELECT attempts.*,users.name,exams.title FROM attempts
                          JOIN users ON users.id=attempts.user_id JOIN exams ON exams.id=attempts.exam_id
                          ORDER BY attempts.id DESC LIMIT 50""").fetchall()
    c.close(); return render_template("staff.html",students=students,exams=exams,attempts=attempts)

@app.route("/staff/add-student",methods=["POST"])
def add_student():
    if not auth(["college","admin"]): return redirect("/login")
    c=con()
    try:
        c.execute("""INSERT INTO users(name,email,password,role,course,semester,phone,created_at)
                     VALUES(?,?,?,?,?,?,?,?)""",(request.form["name"],request.form["email"],request.form["password"],
                     "student",request.form["course"],request.form["semester"],request.form["phone"],datetime.datetime.now().isoformat()))
        c.commit(); flash("Student added.")
    except sqlite3.IntegrityError: flash("Email already exists.")
    c.close(); return redirect("/staff")

@app.route("/staff/add-exam",methods=["POST"])
def add_exam():
    if not auth(["college","faculty","admin"]): return redirect("/login")
    c=con()
    c.execute("""INSERT INTO exams(title,subject,course,semester,duration,instructions) VALUES(?,?,?,?,?,?)""",
              (request.form["title"],request.form["subject"],request.form["course"],request.form["semester"],
               int(request.form["duration"]),request.form["instructions"]))
    c.commit(); c.close(); flash("Exam created. Add questions through database/admin extension in next phase."); return redirect("/staff")

@app.route("/admin")
def admin():
    if not auth(["admin"]): return redirect("/login")
    c=con()
    counts={k:c.execute(sql).fetchone()["n"] for k,sql in {
      "users":"SELECT COUNT(*) n FROM users","students":"SELECT COUNT(*) n FROM users WHERE role='student'",
      "exams":"SELECT COUNT(*) n FROM exams","attempts":"SELECT COUNT(*) n FROM attempts",
      "jobs":"SELECT COUNT(*) n FROM jobs","institutes":"SELECT COUNT(*) n FROM institutes"}.items()}
    c.close(); return render_template("admin.html",counts=counts)

@app.route("/download-report")
def download_report():
    if not auth(["college","admin","faculty"]): return redirect("/login")
    c=con(); rows=c.execute("""SELECT users.name,users.email,exams.title,attempts.score,attempts.total,
                               attempts.submitted_at FROM attempts JOIN users ON users.id=attempts.user_id
                               JOIN exams ON exams.id=attempts.exam_id ORDER BY attempts.id""").fetchall(); c.close()
    out=io.StringIO(); w=csv.writer(out); w.writerow(["Student","Email","Exam","Score","Total","Submitted"])
    for r in rows:w.writerow(list(r))
    data=io.BytesIO(out.getvalue().encode()); data.seek(0)
    return send_file(data,as_attachment=True,download_name="campusai_exam_report.csv",mimetype="text/csv")

if __name__=="__main__":
    os.makedirs(os.path.dirname(DB),exist_ok=True); init_db(); app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
